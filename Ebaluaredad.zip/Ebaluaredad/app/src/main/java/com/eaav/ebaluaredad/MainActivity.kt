package com.eaav.ebaluaredad

import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.eaav.ebaluaredad.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityMainBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        startApp()

        }

    private fun startApp() {
        binding.btnEvaluar.setOnClickListener {
            val age = binding.etAge.text.toString().toInt()
            val messageStr = if (age>=18)"Mayor de Edad" else "Menor de Edad"
            Toast.makeText(this, messageStr, Toast.LENGTH_SHORT).show()
        }
    }
}
