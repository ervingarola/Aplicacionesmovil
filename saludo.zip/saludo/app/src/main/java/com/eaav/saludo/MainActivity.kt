package com.eaav.saludo

import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.eaav.saludo.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var binding : ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityMainBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)

        startApp()

    }

    private fun startApp() {
        binding.btnSaludo.setOnClickListener {
            val name = binding.etName.text.toString()
            val lastNam = binding.etLastName.text.toString()
            val strSaludo = "Hola $name $lastNam"
            Toast.makeText(this, strSaludo, Toast.LENGTH_LONG).show()
        }
    }

}
